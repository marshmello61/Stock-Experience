# Speaker Blast Mod for Moto G5sPlus / May work on other AOSP/LOS based Roms.

This module increases the Default volume of Headphones/LoudSpeakers. 
Do check the version code carefully. The format is VersionCode/*presetlevel**type* where preset level is the level of volume increased, and type is H-Headphones, S-LoudSpeakers.
for example, V1.1/90H. here preset is 90 and H stads for headphone, so this specific module INCREASES THE VOLUME OF HEADPHONES to PRESET 90.

## Installation instructions:
* IMPORTANT- FLASH MODULE IN TWRP. For some reasons the module wont flash in Magisk. Will fix that later.
* Reboot normally, Done!!

## Caution**
  As i told before use any preset with caution, I will not be responsible for any loss.
  KEEP YOUR VOLUME LOW ALWAYS PLAYING MUSIC FIRST TIME.

## Uninstall:
 Disable the module in Magsik Manager, Thats it.

## Notes
 All work on this mod is done by marshmello_61@xda and Magisk Module is prepared by marshmello_61@xda.
